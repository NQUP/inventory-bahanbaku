@extends('layouts.app')

@section('title', 'Riwayat Pemesanan')

@section('content')
<div class="max-w-7xl mx-auto px-4 py-6">

    <div class="flex items-center justify-between mb-4">
        <h2 class="text-2xl font-bold text-purple-700 flex items-center gap-2">
            <i class="bi bi-clock-history"></i> ⏱ Riwayat Pemesanan Bahan Baku
        </h2>
        <div class="flex gap-2">
            <a href="{{ route('supplier.riwayat.pdf', request()->only('tanggal')) }}" class="btn btn-sm btn-error text-white">
                <i class="bi bi-file-earmark-pdf-fill mr-1"></i> PDF
            </a>
            <a href="{{ route('supplier.riwayat.excel', request()->only('tanggal')) }}" class="btn btn-sm btn-success text-white">
                <i class="bi bi-file-earmark-excel-fill mr-1"></i> Excel
            </a>
        </div>
    </div>

    {{-- Form Filter Tanggal --}}
    <div class="mb-4 flex items-center gap-2">
        <form method="GET" action="{{ route('supplier.riwayat') }}" class="flex items-center gap-2">
            <label for="tanggal" class="font-semibold">Filter Tanggal:</label>
            <input type="date" name="tanggal" id="tanggal" 
                   class="input input-bordered input-sm"
                   value="{{ request('tanggal') }}">
            <button type="submit" class="btn btn-sm btn-primary">Filter</button>
            <a href="{{ route('supplier.riwayat') }}" class="btn btn-sm btn-secondary">Reset</a>
        </form>
    </div>

    @if ($riwayat->isEmpty())
        <div class="alert alert-info shadow text-center">Tidak ada riwayat pemesanan.</div>
    @else
        <div class="overflow-x-auto rounded-xl border border-base-200 shadow-lg">
            <table class="table table-zebra w-full">
                <thead class="bg-base-200 text-base-content">
                    <tr>
                        <th>#</th>
                        <th>Kode</th>
                        <th>Tanggal</th>
                        <th>Bahan Baku</th>
                        <th>Jumlah</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($riwayat as $item)
                        <tr>
                            <td>{{ $loop->iteration }}</td>
                            <td class="font-mono text-purple-700">{{ $item->kode ?? '-' }}</td>
                            <td>{{ $item->updated_at?->format('d-m-Y') ?? '-' }}</td>
                            <td>{{ $item->bahanBaku->nama ?? '-' }}</td>
                            <td>{{ number_format($item->jumlah, 2, ',', '.') }}
                                {{ $item->bahanBaku->satuan ?? '' }}</td>
                            @php
                                $badgeMap = [
                                    'menunggu_supplier' => 'badge badge-warning text-white',
                                    'selesai' => 'badge badge-success text-white',
                                    'ditolak' => 'badge badge-error text-white',
                                    'dikirim' => 'badge badge-info text-white',
                                ];
                                $status = strtolower($item->status);
                            @endphp
                            <td>
                                <span class="{{ $badgeMap[$status] ?? 'badge' }}">
                                    {{ ucfirst(str_replace('_', ' ', $status)) }}
                                </span>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    @endif
</div>
@endsection
