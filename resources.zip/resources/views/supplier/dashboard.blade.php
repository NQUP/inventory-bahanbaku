@extends('layouts.app')

@section('title', 'Dashboard Supplier')

@section('content')
<div class="max-w-7xl mx-auto px-4 py-6 space-y-6">

    {{-- Judul --}}
    <div class="mb-8 text-center">
        <div class="inline-flex items-center justify-center p-4 bg-purple-100 rounded-2xl shadow-md mb-3">
            <i class="bi bi-truck text-3xl text-purple-700"></i>
        </div>
        <h2 class="font-extrabold text-purple-700 mb-2" style="font-size: 50px;">
            Dashboard Supplier
        </h2>
        <p class="text-gray-500 text-base max-w-2xl mx-auto">
            Kelola kebutuhan bahan baku, pantau pesanan, dan pastikan distribusi berjalan lancar serta tepat waktu.
        </p>
    </div>

    {{-- Statistik --}}
    <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <div class="bg-purple-100 p-4 rounded-xl shadow">
            <h5 class="text-purple-700 font-semibold flex items-center gap-1">
                <i class="bi bi-cart-check"></i> Total Permintaan
            </h5>
            <p class="text-3xl font-bold">{{ $total }}</p>
        </div>
        <div class="bg-yellow-100 p-4 rounded-xl shadow">
            <h5 class="text-yellow-800 font-semibold flex items-center gap-1">
                <i class="bi bi-hourglass-split"></i> Menunggu
            </h5>
            <p class="text-3xl font-bold">{{ $menunggu }}</p>
        </div>
        <div class="bg-purple-200 p-4 rounded-xl shadow">
            <h5 class="text-purple-700 font-semibold flex items-center gap-1">
                <i class="bi bi-truck"></i> Dikirim
            </h5>
            <p class="text-3xl font-bold">{{ $dikirim }}</p>
        </div>
        <div class="bg-green-100 p-4 rounded-xl shadow">
            <h5 class="text-green-700 font-semibold flex items-center gap-1">
                <i class="bi bi-check-circle"></i> Selesai
            </h5>
            <p class="text-3xl font-bold">{{ $selesai }}</p>
        </div>
    </div>

    {{-- Tabel Permintaan Terbaru + Tombol Riwayat --}}
<div class="flex flex-wrap items-center justify-between mb-4 w-full">
    {{-- Kiri: Judul --}}
    <h3 class="text-lg font-semibold text-gray-800">
        📋 Permintaan Terbaru
    </h3>

    {{-- Kanan: Tombol Riwayat --}}
    <div class="ml-auto mt-2 md:mt-0">
        <a href="{{ route('supplier.riwayat') }}" class="btn btn-sm btn-primary">
            <i class="bi bi-file-earmark-text"></i> Riwayat Pemesanan
        </a>
    </div>
</div>


    @if ($permintaans->isEmpty())
        <p class="text-gray-500 italic">Belum ada permintaan bahan baku.</p>
    @else
        <div class="overflow-x-auto bg-white rounded-xl shadow">
            <table class="table table-zebra w-full">
                <thead class="bg-base-200 text-base-content">
                    <tr>
                        <th>#</th>
                        <th>Kode Bahan Baku</th>
                        <th>Pemesan</th>
                        <th>Nama Bahan</th>
                        <th>Jumlah</th>
                        <th>Status</th>
                        <th>Tanggal</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($permintaans->take(5) as $index => $item)
                        @php
                            $statusClass = match ($item->status) {
                                'menunggu_supplier' => 'badge badge-warning',
                                'dikirim' => 'badge badge-info',
                                'selesai' => 'badge badge-success',
                                default => 'badge badge-neutral',
                            };
                            $statusEmoji = match ($item->status) {
                                'menunggu_supplier' => '⏳',
                                'dikirim' => '🚚',
                                'selesai' => '✅',
                                default => 'ℹ️',
                            };
                        @endphp
                        <tr>
                            <td>{{ $index + 1 }}</td>
                            <td>{{ $item->kode ?? '-' }}</td>
                            <td>{{ $item->pemesanan->user->name ?? '-' }}</td>
                            <td>{{ $item->bahanBaku->nama ?? '-' }}</td>
                            <td>{{ number_format($item->jumlah, 2, ',', '.') }} kg</td>
                            <td><span class="{{ $statusClass }}">{{ $statusEmoji }} {{ ucwords(str_replace('_',' ', $item->status)) }}</span></td>
                            <td>{{ $item->created_at->format('d M Y') }}</td>
                            <td>
                                @if ($item->status === 'menunggu_supplier')
                                    <div class="flex flex-col sm:flex-row gap-2">
                                        <form action="{{ route('supplier.kirim', $item->id) }}" method="POST" onsubmit="return confirm('Kirim permintaan ini sekarang?')">
                                            @csrf
                                            @method('PUT')
                                            <button type="submit" class="btn btn-xs btn-primary"><i class="bi bi-send"></i> Kirim</button>
                                        </form>
                                        <form action="{{ route('supplier.hapus', $item->id) }}" method="POST" onsubmit="return confirm('Yakin ingin menghapus permintaan ini?')">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-xs btn-error"><i class="bi bi-trash"></i> Hapus</button>
                                        </form>
                                    </div>
                                @else
                                    <span class="text-gray-400 text-xs">-</span>
                                @endif
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    @endif

</div>
@endsection
