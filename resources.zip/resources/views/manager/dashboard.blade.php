@extends('layouts.app')

@section('content')
    <div class="container mx-auto px-4 py-6">
{{-- Judul --}}
<div class="mb-8 text-center">
    <div class="inline-flex items-center justify-center p-6 bg-gradient-to-r from-purple-200 to-purple-100 rounded-2xl shadow-lg mb-4">
        <i class="bi bi-graph-up-arrow text-5xl text-purple-700"></i>
    </div>
    <h2 class="font-extrabold text-purple-700 mb-3" style="font-size: 42px;">
        Dashboard Manager 📊
    </h2>
    <p class="text-gray-600 text-lg max-w-2xl mx-auto">
        Pantau kinerja, analisis data, serta ambil keputusan strategis dengan lebih mudah dan cepat.
    </p>
</div>

        {{-- Tombol Riwayat --}}
        <a href="{{ route('manager.permintaan.riwayat') }}"
            class="inline-block bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700 transition mb-6">
            🕘 Lihat Riwayat Persetujuan
        </a>
        {{-- Kartu Statistik --}}
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            {{-- Total Permintaan --}}
            <div class="card bg-purple-100 text-purple-800 shadow-md">
                <div class="card-body">
                    <h2 class="card-title text-sm">📦 Total Permintaan</h2>
                    <div class="flex items-center justify-between">
                        <p class="text-3xl font-bold">{{ $totalPermintaan }}</p>
                        <i class="bi bi-clipboard-data text-3xl"></i>
                    </div>
                </div>
            </div>

            {{-- Menunggu Persetujuan --}}
            <div class="card bg-yellow-100 text-yellow-800 shadow-md">
                <div class="card-body">
                    <h2 class="card-title text-sm">⏳ Menunggu Persetujuan</h2>
                    <div class="flex items-center justify-between">
                        <p class="text-3xl font-bold">{{ $totalPermintaan }}</p>
                        <i class="bi bi-hourglass-split text-3xl"></i>
                    </div>
                </div>
            </div>
        </div>

        {{-- Flash Message --}}
        @if (session('success'))
            <div class="alert alert-success shadow-lg mb-4">
                <span>✅ {{ session('success') }}</span>
            </div>
        @elseif (session('error'))
            <div class="alert alert-error shadow-lg mb-4">
                <span>❌ {{ session('error') }}</span>
            </div>
        @elseif (session('info'))
            <div class="alert alert-info shadow-lg mb-4">
                <span>ℹ️ {{ session('info') }}</span>
            </div>
        @endif

        {{-- ... sebelumnya tetap ... --}}

        {{-- Permintaan Terbaru --}}
        <div class="card bg-base-100 shadow border border-base-200">
            <div class="card-body">
                <h2 class="card-title text-base-content mb-4">📑 Permintaan Terbaru (Menunggu Persetujuan)</h2>

                @if ($permintaans->isEmpty())
                    <p class="text-sm text-gray-500">Belum ada permintaan bahan baku yang menunggu persetujuan.</p>
                @else
                    <div class="overflow-x-auto">
                        <table class="table table-zebra text-sm">
                            <thead class="bg-purple-100 text-purple-800">
                                <tr>
                                    <th>#</th>
                                    <th>Produk</th>
                                    <th>Bahan Baku</th>
                                    <th class="text-right">Jumlah</th>
                                    <th class="text-right">EOQ</th>
                                    <th class="text-right">ROP</th>
                                    <th>Pemesan</th>
                                    <th>Tanggal</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($permintaans as $index => $p)
                                    <tr>
                                        <td>{{ $index + 1 }}</td>
                                        <td>{{ $p->pemesanan->produk?->produk?->nama ?? '-' }}</td>
                                        <td>{{ $p->bahanBaku?->nama ?? '-' }}</td>
                                        <td class="text-right">
                                            {{ number_format($p->jumlah, 2, ',', '.') }}
                                            {{ $p->bahanBaku?->satuan ?? '-' }}
                                        </td>
                                        <td class="text-right">{{ $p->bahanBaku?->eoqRop?->eoq ?? '-' }}</td>
                                        <td class="text-right">{{ $p->bahanBaku?->eoqRop?->rop ?? '-' }}</td>
                                        <td>{{ $p->pemesanan?->user?->name ?? '-' }}</td>
                                        <td>{{ $p->created_at->translatedFormat('d M Y') }}</td>
                                        <td>
                                            @php
                                                $badgeClass = match ($p->status) {
                                                    'menunggu_persetujuan_manager' => 'badge-warning',
                                                    'disetujui_manager' => 'badge-success',
                                                    'ditolak_manager' => 'badge-error',
                                                    default => 'badge-neutral',
                                                };
                                            @endphp
                                            <span class="badge badge-outline {{ $badgeClass }}">
                                                {{ Str::headline(str_replace('_', ' ', $p->status)) }}
                                            </span>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>

                    {{-- Tombol Lihat Semua --}}
                    <div class="mt-4 text-right">
                        <a href="{{ route('manager.permintaan.index') }}"
                            class="text-purple-700 hover:underline text-sm font-medium">
                            📋 Lihat Semua Permintaan →
                        </a>
                    </div>
                @endif
            </div>
        </div>
    </div>
@endsection
