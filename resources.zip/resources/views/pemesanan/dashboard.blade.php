@extends('layouts.app')

@section('content')
<div class="max-w-7xl mx-auto px-4 py-6 space-y-6">

    {{-- Judul --}}
    <div class="mb-8 text-center">
        <div class="inline-flex items-center justify-center p-4 bg-purple-100 rounded-2xl shadow-md mb-3">
            <i class="bi bi-speedometer2 text-3xl text-purple-700"></i>
        </div>
        <h2 class="font-extrabold text-purple-700 mb-2" style="font-size: 50px;">
            Dashboard Pemesanan Produk Jadi 📊
        </h2>
        <p class="text-gray-500 text-base max-w-2xl mx-auto">
            Pantau dan kelola aktivitas pemesanan produk jadi dengan mudah, cepat, dan real-time.
        </p>
    </div>

    {{-- Filter --}}
    <form method="GET" class="bg-base-200 p-4 rounded-lg shadow-md flex flex-wrap items-center gap-4">
        <div class="flex items-center gap-2">
            <label for="status" class="font-semibold">Status:</label>
            <select name="status" id="status" onchange="this.form.submit()" class="select select-bordered select-sm">
                <option value="">Semua 🌈</option>
                <option value="Pending" {{ request('status') == 'Pending' ? 'selected' : '' }}>⏳ Pending</option>
                <option value="Dikirim" {{ request('status') == 'Dikirim' ? 'selected' : '' }}>🚚 Dikirim</option>
                <option value="Selesai" {{ request('status') == 'Selesai' ? 'selected' : '' }}>✅ Selesai</option>
            </select>
        </div>

        <div class="flex items-center gap-2">
            <label for="tanggal" class="font-semibold">Tanggal:</label>
            <input type="date" name="tanggal" id="tanggal" value="{{ request('tanggal') }}" onchange="this.form.submit()"
                class="input input-bordered input-sm">
        </div>
    </form>

    {{-- Tombol --}}
    <div class="flex flex-wrap justify-between items-center gap-3">
        <a href="{{ route('pemesanan.create') }}" class="btn btn-primary">
            <i class="bi bi-plus-circle"></i> Tambah Pemesanan
        </a>
        <div class="flex gap-2">
            <a href="{{ route('pemesanan.export.pdf', request()->query()) }}" class="btn btn-outline btn-error">
                <i class="bi bi-file-earmark-pdf"></i> Export PDF 📄
            </a>
            <a href="{{ route('pemesanan.export.excel', request()->query()) }}" class="btn btn-outline btn-success">
                <i class="bi bi-file-earmark-excel"></i> Export Excel 📊
            </a>
        </div>
    </div>

    {{-- Statistik --}}
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div class="bg-purple-100 p-4 rounded-xl shadow">
            <h5 class="text-purple-700 font-semibold flex items-center gap-1">
                <i class="bi bi-cart-check"></i> Total Pemesanan 🛒
            </h5>
            <p class="text-3xl font-bold">{{ $total }}</p>
        </div>
        <div class="bg-purple-200 p-4 rounded-xl shadow">
            <h5 class="text-purple-700 font-semibold flex items-center gap-1">
                <i class="bi bi-hourglass-split"></i> Belum Selesai ⏳
            </h5>
            <p class="text-3xl font-bold">{{ $belumSelesai }}</p>
        </div>
        <div class="bg-purple-300 p-4 rounded-xl shadow">
            <h5 class="text-purple-700 font-semibold flex items-center gap-1">
                <i class="bi bi-check-circle"></i> Selesai ✅
            </h5>
            <p class="text-3xl font-bold">{{ $selesai }}</p>
        </div>
    </div>

    {{-- Tabel --}}
    <div class="overflow-x-auto bg-white rounded-xl shadow mt-4">
        <table class="table table-zebra w-full">
            <thead class="bg-base-200 text-base-content">
                <tr>
                    <th>#</th>
                    <th>Kode Produk</th>
                    <th>Nama Produk</th>
                    <th>Jumlah</th>
                    <th>Tipe</th>
                    <th>Status</th>
                    <th>Tanggal</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse ($pemesanans as $p)
                    @php
                        $jumlahUnit = $p->jumlah ?? 0;
                        $totalBahanGram = $p->produk?->details->sum(fn($d) => $d->jumlah_per_produk * $jumlahUnit) ?? 0;
                        $totalBahanKg = $totalBahanGram / 1000;
                        $badgeClass = match ($p->status) {
                            'Selesai' => 'badge badge-success',
                            'Dikirim' => 'badge badge-info',
                            'Pending' => 'badge badge-warning text-black',
                            default => 'badge badge-neutral',
                        };
                        $badgeEmoji = match ($p->status) {
                            'Selesai' => '✅',
                            'Dikirim' => '🚚',
                            'Pending' => '⏳',
                            default => '',
                        };
                    @endphp
                    <tr>
                        <td>{{ $loop->iteration + ($pemesanans->currentPage() - 1) * $pemesanans->perPage() }}</td>
                        <td>{{ $p->kode ?? '-' }}</td>
                        <td>{{ $p->produk?->produk?->nama ?? '-' }}</td>
                        <td>
                            {{ number_format($p->jumlah) }} Unit<br>
                            <span class="text-xs text-gray-500">{{ number_format($totalBahanKg, 2) }} kg bahan baku</span>
                        </td>
                        <td>{{ $p->tipe ?? '-' }}</td>
                        <td><span class="{{ $badgeClass }}">{{ $badgeEmoji }} {{ $p->status }}</span></td>
                        <td>{{ $p->created_at->format('d M Y') }}</td>
                        <td>
                            @if ($p->status === 'Pending')
                                <div class="flex flex-col sm:flex-row gap-2">
                                    <a href="{{ route('pemesanan.edit', $p->id) }}" class="btn btn-xs btn-warning">
                                        <i class="bi bi-pencil-square"></i> ✏️ Edit
                                    </a>
                                    <form action="{{ route('pemesanan.destroy', $p->id) }}" method="POST"
                                        onsubmit="return confirm('Yakin ingin menghapus pemesanan ini?')">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-xs btn-error">
                                            <i class="bi bi-trash"></i> 🗑️ Hapus
                                        </button>
                                    </form>
                                </div>
                            @else
                                <span class="text-sm text-gray-400">-</span>
                            @endif
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="8" class="text-center text-gray-500 py-4 italic">Belum ada data pemesanan.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    {{-- Pagination --}}
    <div class="mt-6">
        {{ $pemesanans->withQueryString()->links() }}
    </div>
</div>
@endsection
