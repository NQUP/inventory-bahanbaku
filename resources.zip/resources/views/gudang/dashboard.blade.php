@extends('layouts.app')

@section('title', 'Dashboard Gudang')

@section('content')
<div class="max-w-7xl mx-auto px-4 py-6 space-y-6">

    {{-- Judul --}}
    <div class="mb-8 text-center">
        <div class="inline-flex items-center justify-center p-4 bg-purple-100 rounded-2xl shadow-md mb-3">
            <i class="bi bi-box-seam text-3xl text-purple-700"></i>
        </div>
        <h2 class="font-extrabold text-purple-700 mb-2" style="font-size: 50px;">
            Dashboard Gudang
        </h2>
        <p class="text-gray-500 text-base max-w-2xl mx-auto">
            Pantau permintaan bahan baku terbaru, kelola status, dan pastikan distribusi berjalan lancar.
        </p>
    </div>

    {{-- Statistik --}}
    <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <div class="bg-purple-100 p-4 rounded-xl shadow">
            <h5 class="text-purple-700 font-semibold flex items-center gap-1">
                <i class="bi bi-clipboard-data"></i> Total Permintaan
            </h5>
            <p class="text-3xl font-bold">{{ $totalPermintaan }}</p>
        </div>
        <div class="bg-yellow-100 p-4 rounded-xl shadow">
            <h5 class="text-yellow-800 font-semibold flex items-center gap-1">
                <i class="bi bi-hourglass-split"></i> Menunggu
            </h5>
            <p class="text-3xl font-bold">{{ $menunggu }}</p>
        </div>
        <div class="bg-green-100 p-4 rounded-xl shadow">
            <h5 class="text-green-700 font-semibold flex items-center gap-1">
                <i class="bi bi-check-circle"></i> Disetujui
            </h5>
            <p class="text-3xl font-bold">{{ $disetujui }}</p>
        </div>
        <div class="bg-red-100 p-4 rounded-xl shadow">
            <h5 class="text-red-700 font-semibold flex items-center gap-1">
                <i class="bi bi-x-circle"></i> Ditolak
            </h5>
            <p class="text-3xl font-bold">{{ $ditolak }}</p>
        </div>
    </div>

    {{-- Permintaan Terbaru --}}
    <div class="flex flex-wrap items-center justify-between mb-4 w-full">
        {{-- Kiri: Judul --}}
        <h3 class="text-lg font-semibold text-gray-800">
            📋 Permintaan Terbaru
        </h3>

        {{-- Kanan: Tombol Riwayat --}}
        <div class="ml-auto mt-2 md:mt-0">
            <a href="{{ route('gudang.permintaan.riwayat') }}" class="btn btn-sm btn-primary">
                <i class="bi bi-file-earmark-text"></i> Riwayat Permintaan
            </a>
        </div>
    </div>

    @if ($permintaansTerbaru->isEmpty())
        <p class="text-gray-500 italic">Belum ada data permintaan.</p>
    @else
        <div class="overflow-x-auto bg-white rounded-xl shadow">
            <table class="table table-zebra w-full">
                <thead class="bg-base-200 text-base-content">
                    <tr>
                        <th>#</th>
                        <th>Kode Permintaan</th>
                        <th>Nama Bahan</th>
                        <th>Jumlah</th>
                        <th>Status</th>
                        <th>Tanggal</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($permintaansTerbaru as $index => $permintaan)
                        @php
                            $badgeMap = [
                                'menunggu_supplier' => 'badge badge-warning',
                                'disiapkan' => 'badge badge-success',
                                'ditolak' => 'badge badge-error',
                                'dikirim' => 'badge badge-info',
                                'selesai' => 'badge badge-neutral',
                            ];
                            $badgeClass = $badgeMap[$permintaan->status] ?? 'badge badge-neutral';
                            $label = ucfirst(str_replace('_', ' ', $permintaan->status));
                        @endphp
                        <tr class="border-t hover:bg-gray-50">
                            <td>{{ $index + 1 }}</td>
                            <td class="font-mono text-blue-700">{{ $permintaan->kode ?? '-' }}</td>
                            <td>{{ $permintaan->bahanBaku->nama ?? '-' }}</td>
                            <td>{{ number_format($permintaan->jumlah, 0, ',', '.') }} {{ $permintaan->bahanBaku->satuan ?? '' }}</td>
                            <td><span class="{{ $badgeClass }} text-xs font-semibold px-3 py-1 rounded-full">{{ $label }}</span></td>
                            <td>{{ $permintaan->created_at->format('d M Y') }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>

        {{-- ✅ Tombol Lihat Semua --}}
        <div class="text-end mt-4">
            <a href="{{ route('gudang.permintaan.index') }}"
                class="inline-flex items-center gap-2 text-sm px-4 py-2 border border-purple-600 text-purple-700 rounded hover:bg-purple-50">
                <i class="bi bi-arrow-right-circle"></i> 🔍 Lihat Semua Permintaan
            </a>
        </div>
    @endif

</div>
@endsection
