@extends('layouts.app')

@section('title', 'Riwayat Permintaan Gudang')

@section('content')
    <div class="max-w-7xl mx-auto px-4 py-6">

        <div class="flex items-center justify-between mb-6">
            <h2 class="text-2xl font-bold text-purple-700 flex items-center gap-2">
                <i class="bi bi-clock-history"></i> 📜 Riwayat Permintaan Bahan Baku
            </h2>

            <div class="flex gap-2">
                <a href="{{ route('gudang.riwayat.export.pdf', ['tanggal' => request('tanggal')]) }}" class="btn btn-sm btn-error text-white">
                    <i class="bi bi-file-earmark-pdf-fill mr-1"></i> PDF
                </a>
                <a href="{{ route('gudang.riwayat.export.excel', ['tanggal' => request('tanggal')]) }}" class="btn btn-sm btn-success text-white">
                    <i class="bi bi-file-earmark-excel-fill mr-1"></i> Excel
                </a>
            </div>
        </div>

        <!-- Filter Tanggal -->
        <form action="{{ route('gudang.permintaan.riwayat') }}" method="GET" class="mb-4 flex items-center gap-2">
            <label for="tanggal" class="font-medium">Filter Tanggal:</label>
            <input type="date" id="tanggal" name="tanggal" value="{{ request('tanggal') }}" class="input input-bordered input-sm">
            <button type="submit" class="btn btn-sm btn-primary">Filter</button>
            <a href="{{ route('gudang.permintaan.riwayat') }}" class="btn btn-sm btn-outline">Reset</a>
        </form>

        @if ($permintaans->isEmpty())
            <div class="alert alert-info shadow text-center">Belum ada permintaan sesuai filter.</div>
        @else
            <div class="overflow-x-auto rounded-xl border border-base-200 shadow-lg">
                <table class="table table-zebra w-full">
                    <thead class="bg-base-200 text-base-content">
                        <tr>
                            <th>#</th>
                            <th>Kode</th>
                            <th>Tanggal</th>
                            <th>Bahan Baku</th>
                            <th>Jumlah</th>
                            <th>Pemesan</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($permintaans as $permintaan)
                            <tr>
                                <td>{{ $loop->iteration }}</td>
                                <td>{{ $permintaan->kode ?? '-' }}</td>
                                <td>{{ $permintaan->updated_at->format('d-m-Y') }}</td>
                                <td>{{ $permintaan->bahanBaku->nama ?? '-' }}</td>
                                <td>{{ number_format($permintaan->jumlah, 0, ',', '.') }}</td>
                                <td>{{ $permintaan->pemesanan->user->name ?? '-' }}</td>
                                @php
                                    $badgeMap = [
                                        'menunggu_supplier' => 'badge badge-warning text-white',
                                        'disiapkan' => 'badge badge-success text-white',
                                        'ditolak' => 'badge badge-error text-white',
                                        'dikirim' => 'badge badge-info text-white',
                                        'selesai' => 'badge badge-neutral text-white',
                                    ];
                                    $status = strtolower($permintaan->status);
                                @endphp
                                <td>
                                    <span class="{{ $badgeMap[$status] ?? 'badge' }}">
                                        {{ ucfirst(str_replace('_', ' ', $status)) }}
                                    </span>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        @endif
    </div>
@endsection
