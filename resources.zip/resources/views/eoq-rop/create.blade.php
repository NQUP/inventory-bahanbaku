@extends('layouts.app')

@section('title', '📦 Input Parameter EOQ & ROP')

@section('content')
    <div class="max-w-3xl mx-auto mt-10 bg-white rounded-2xl shadow-lg p-8 border border-purple-300">
        <h1 class="text-2xl font-bold text-purple-700 mb-6 flex items-center gap-2">
            📈 Input Parameter EOQ & ROP
        </h1>

        <form action="{{ route(Auth::user()->role == 'admin' ? 'admin.eoq-rop.store' : 'manager.eoq-rop.store') }}"
            method="POST" class="space-y-4">
            @csrf
            <input type="hidden" name="bahan_baku_id" value="{{ $bahanBaku->id }}">

            <div>
                <label class="label">
                    <span class="label-text font-semibold text-purple-700">🔧 Nama Bahan Baku</span>
                </label>
                <input type="text" class="input input-bordered w-full bg-gray-100 text-gray-600"
                    value="{{ $bahanBaku->nama }}" disabled>
            </div>

            <div>
                <label class="label">
                    <span class="label-text font-semibold text-purple-700">📦 Permintaan Tahunan (Unit)</span>
                </label>
                <input type="number" name="demand_tahunan" class="input input-bordered w-full" placeholder="Contoh: 1000"
                    required>
            </div>

            <div>
                <label class="label">
                    <span class="label-text font-semibold text-purple-700">💸 Biaya Pemesanan per Order (Rp)</span>
                </label>
                <input type="number" name="biaya_pemesanan" class="input input-bordered w-full" placeholder="Contoh: 50000"
                    required>
            </div>

            <div>
                <label class="label">
                    <span class="label-text font-semibold text-purple-700">🏷️ Biaya Penyimpanan per Unit per Tahun
                        (Rp)</span>
                </label>
                <input type="number" name="biaya_penyimpanan" class="input input-bordered w-full"
                    placeholder="Contoh: 10000" required>
            </div>

            <div>
                <label class="label">
                    <span class="label-text font-semibold text-purple-700">⏱️ Lead Time (Hari)</span>
                </label>
                <input type="number" name="lead_time" class="input input-bordered w-full" placeholder="Contoh: 5" required>
            </div>

            <div class="text-right">
                <button type="submit" class="btn bg-purple-600 text-white hover:bg-purple-700 transition-all duration-200">
                    🚀 Hitung EOQ & ROP
                </button>
            </div>
        </form>
    </div>
@endsection
