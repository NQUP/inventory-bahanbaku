@extends('layouts.guest')

@section('content')
    {{-- Header Logo dan Judul --}}
    <div class="text-center mb-6">
        <img src="{{ asset('images/logopt.png') }}" alt="Logo" class="w-20 h-19 mx-auto">
        <h1 class="text-2xl font-bold text-primary mt-2">Selamat Datang</h1>
        <p class="text-sm text-base-content">Silakan masuk ke akun Anda</p>
    </div>

    <!-- Session Status -->
    <x-auth-session-status class="mb-4" :status="session('status')" />

    <!-- Login Form -->
    <form method="POST" action="{{ route('login') }}" class="card bg-base-100 shadow-md p-6 space-y-4">
        @csrf

        <!-- Email -->
        <div class="form-control">
            <label for="email" class="label">
                <span class="label-text font-medium">Email</span>
            </label>
            <input id="email" type="email" name="email" :value="old('email')" required autofocus
                autocomplete="username" class="input input-bordered w-full" />
            <x-input-error :messages="$errors->get('email')" class="mt-1 text-error" />
        </div>

        <!-- Password -->
        <div class="form-control">
            <label for="password" class="label">
                <span class="label-text font-medium">Password</span>
            </label>
            <input id="password" type="password" name="password" required autocomplete="current-password"
                class="input input-bordered w-full" />
            <x-input-error :messages="$errors->get('password')" class="mt-1 text-error" />
        </div>

        <!-- Remember Me -->
        <div class="form-control">
            <label class="label cursor-pointer justify-start gap-2">
                <input type="checkbox" name="remember" class="checkbox checkbox-primary" />
                <span class="label-text">Ingat Saya</span>
            </label>
        </div>

        <!-- Submit & Forgot Password -->
        <div class="form-control mt-4 flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
            @if (Route::has('password.request'))
                <a href="{{ route('password.request') }}" class="link link-hover text-sm text-primary">
                    Lupa Password?
                </a>
            @endif

            <button type="submit" class="btn btn-primary">
                Masuk
            </button>
        </div>
    </form>
@endsection
