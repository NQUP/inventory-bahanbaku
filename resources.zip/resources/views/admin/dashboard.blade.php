@extends('layouts.app')

@section('content')
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
{{-- Judul --}}
<div class="mb-8 text-center">
    <div class="inline-flex items-center justify-center p-4 bg-purple-100 rounded-2xl shadow-md mb-3">
        <i class="bi bi-bar-chart-line text-3xl text-purple-700"></i>
    </div>
   <h2 class="font-extrabold text-purple-700 mb-2" style="font-size: 50px;">
    Dashboard Admin <i class="bi bi-rocket-takeoff text-purple-600"></i>
</h2>
    <p class="text-gray-500 text-base max-w-2xl mx-auto">
        Kelola data pemesanan, pantau stok bahan baku, dan pastikan operasional berjalan efisien.
    </p>
</div>

        {{-- Statistik --}}
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div class="card bg-gradient-to-br from-purple-600 to-indigo-600 text-white shadow-lg">
                <div class="card-body">
                    <h4 class="card-title">Total Pemesanan</h4>
                    <p class="text-3xl font-bold">{{ number_format($data->totalPemesanan, 0, ',', '.') }}</p>
                </div>
            </div>
            <div class="card bg-gradient-to-br from-red-500 to-red-700 text-white shadow-lg">
                <div class="card-body">
                    <h4 class="card-title">Pemesanan Belum Selesai</h4>
                    <p class="text-3xl font-bold">{{ number_format($data->pemesananBelumSelesai, 0, ',', '.') }}</p>
                </div>
            </div>
        </div>

        {{-- Notifikasi Bahan Baku Menipis --}}
        <div class="collapse collapse-arrow bg-yellow-100 shadow">
            <input type="checkbox" />
            <div class="collapse-title font-bold text-yellow-900">
                ⚠️ Bahan Baku Menipis ({{ $data->bahanMenipis->count() }})
            </div>
            <div class="collapse-content">
                @if ($data->bahanMenipis->isEmpty())
                    <p class="text-gray-600">Tidak ada bahan baku yang menipis.</p>
                @else
                    <table class="table table-sm">
                        <thead>
                            <tr>
                                <th>Nama</th>
                                <th>Stok</th>
                                <th>Minimum</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($data->bahanMenipis as $bahan)
                                <tr class="hover:bg-gray-50 transition">
                                    <td>{{ $bahan->nama }}</td>
                                    <td>{{ number_format($bahan->stok, 2, ',', '.') }} {{ $bahan->satuan }}</td>
                                    <td>{{ number_format($bahan->stok_minimum, 2, ',', '.') }} {{ $bahan->satuan }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                @endif
            </div>
        </div>

        {{-- Semua Bahan --}}
        <div class="card bg-base-100 shadow-md">
            <div class="card-body">
                <h4 class="card-title border-l-4 border-purple-500 pl-3 text-gray-700">
                    📦 Stok Seluruh Bahan Baku ({{ $data->semuaBahan->count() }})
                </h4>
                @if ($data->semuaBahan->isEmpty())
                    <p class="text-gray-500">Belum ada data bahan baku.</p>
                @else
                    <div class="overflow-x-auto">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Nama</th>
                                    <th>Stok</th>
                                    <th>Satuan</th>
                                    <th>EOQ</th>
                                    <th>ROP</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($data->semuaBahan as $bahan)
                                    <tr class="hover:bg-gray-50 transition">
                                        <td>{{ $bahan->nama }}</td>
                                        <td>{{ number_format($bahan->stok, 2, ',', '.') }}</td>
                                        <td>{{ $bahan->satuan ?? '-' }}</td>
                                        <td>{{ $bahan->eoqRop->eoq ?? 'Belum ada' }}</td>
                                        <td>{{ $bahan->eoqRop->rop ?? 'Belum ada' }}</td>
                                        <td>
                                            <a href="{{ route('admin.eoq-rop.create', $bahan->id) }}"
                                                class="btn btn-xs btn-outline btn-primary">
                                                Input EOQ/ROP
                                            </a>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                @endif
            </div>
        </div>

        {{-- Pesanan Terbaru --}}
        <div class="card bg-purple-50 shadow border border-purple-200">
            <div class="card-body p-4">
                <div class="flex justify-between items-center mb-4">
                    <h4 class="card-title text-purple-700 flex items-center gap-2">
                        🕒 Pesanan Terbaru
                    </h4>
                    <span class="badge bg-purple-500 text-white">
                        {{ $data->pesananTerbaru->count() }} Pesanan
                    </span>
                </div>
                @if ($data->pesananTerbaru->isEmpty())
                    <p class="text-gray-500">Belum ada pesanan terbaru.</p>
                @else
                    <div class="overflow-x-auto">
                        <table class="table table-sm">
                            <thead class="text-purple-900">
                                <tr>
                                    <th>Pemesan</th>
                                    <th>Produk</th>
                                    <th><strong>Kode Produk</strong></th>
                                    <th>Jumlah</th>
                                    <th>Status</th>
                                    <th>Tanggal</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($data->pesananTerbaru as $pesanan)
                                    @php
                                        $status = strtolower($pesanan->status_admin ?? '-');
                                        $badge = match ($status) {
                                            'disetujui' => 'bg-green-600 text-white',
                                            'pending' => 'bg-yellow-400 text-black',
                                            'ditolak' => 'bg-red-600 text-white',
                                            default => 'bg-gray-400 text-white',
                                        };
                                    @endphp
                                    <tr class="hover:bg-gray-50 transition">
                                        <td>{{ optional($pesanan->user)->name ?? '-' }}</td>
                                        <td>{{ optional($pesanan->produk?->produk)->nama ?? '-' }}</td>
                                        <td>{{ $pesanan->kode ?? '-' }}</td> {{-- Ini adalah Kode Pemesanan --}}
                                        <td>{{ number_format($pesanan->jumlah, 0, ',', '.') }}</td>
                                        <td>
                                            <span class="badge {{ $badge }}">{{ ucfirst($status) }}</span>
                                        </td>
                                        <td>{{ $pesanan->created_at->format('d M Y') }}</td>
                                        <td>
                                            @if ($pesanan->status_admin === 'pending')
                                                <div class="flex gap-2">
                                                    <form method="POST"
                                                        action="{{ route('admin.pemesanan.setujui', $pesanan->id) }}">
                                                        @csrf
                                                        <button class="btn btn-success btn-xs">Setujui</button>
                                                    </form>
                                                    <form method="POST"
                                                        action="{{ route('admin.pemesanan.tolak', $pesanan->id) }}">
                                                        @csrf
                                                        <button class="btn btn-error btn-xs">Tolak</button>
                                                    </form>
                                                </div>
                                            @else
                                                <span class="text-gray-500 text-sm">Sudah diproses</span>
                                            @endif
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                @endif

                <div class="text-right mt-4">
                    <a href="{{ route('admin.pemesanan.index') }}" class="link text-purple-700">Lihat Semua Pemesanan</a>
                </div>
            </div>
        </div>

        {{-- Grafik --}}
        <div class="card bg-white shadow">
            <div class="card-body">
                <h4 class="card-title border-l-4 border-purple-500 pl-3 text-gray-700 mb-4">
                    📊 Grafik Pemakaian Bahan Baku (6 Bulan Terakhir)
                </h4>
                @if (empty($data->grafikPemakaian['data']))
                    <p class="text-gray-500">Belum ada data pemakaian bahan baku.</p>
                @else
                    <canvas id="grafikPemakaian"></canvas>
                @endif
            </div>
        </div>
    </div>
@endsection

@push('scripts')
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        const ctx = document.getElementById('grafikPemakaian')?.getContext('2d');
        if (ctx) {
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: @json($data->grafikPemakaian['labels'] ?? []),
                    datasets: [{
                        label: 'Pemakaian (kg)',
                        data: @json($data->grafikPemakaian['data'] ?? []),
                        backgroundColor: 'rgba(124, 58, 237, 0.2)', // Ungu
                        borderColor: 'rgba(124, 58, 237, 1)',
                        pointBackgroundColor: 'rgba(124, 58, 237, 1)',
                        borderWidth: 2,
                        fill: true,
                        tension: 0.3,
                        pointRadius: 4,
                        pointHoverRadius: 6,
                        pointBorderColor: '#fff',
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return ' ' + context.parsed.y + ' kg';
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: function(value) {
                                    return value + ' kg';
                                }
                            }
                        }
                    }
                }
            });
        }
    </script>
@endpush
